let reviews = [
  {
      "id": 1,
      "nome": "Dona Creuza",
      "estrelas": 5,
      "comentario": "Muito bom, recomendo!"
  },
  {
      "id": 2,
      "nome": "Lara Damas",
      "estrelas": 4,
      "comentario": "Ótimo"
  },
  {
      "id": 3,
      "nome": "Pedro Nantes",
      "estrelas": 5,
      "comentario": "Excelente! Superou as expectativas."
  }
]
;
let slideIndex = 0;

function getEvents() {
  let events = JSON.parse(localStorage.getItem('events')) || [];
  return events;
}

function addEventsToReviews() {
  const events = getEvents();
  events.forEach(event => {
      const newReview = {
          id: reviews.length + 1,  
          nome: event.name,
          estrelas: parseInt(event.rating),  
          comentario: event.title
      };
      reviews.push(newReview);
  });
}

function loadStars(stars){
  const calculatedStars = [];
  for (let i = 0; i < Math.floor(stars); i++){
    calculatedStars.push(`<img src="images/full-star.svg" class="stars">`);
  }
  if(stars === 5){
    return calculatedStars.map((item) => item).join('');
  }
  if(Number.isInteger(stars)){
    for (let i = 0; i < 5 - stars; i++){
      calculatedStars.push(`<img src="images/empty-star.svg" class="reviewstars">`);
    }
  } else {
    calculatedStars.push(`<img src="images/half-star.svg" class="reviewstars">`);
    for (let i = 0; i < 4 - Math.floor(stars); i++){
      calculatedStars.push(`<img src="images/empty-star.svg" class="reviewstars">`);
    }
  }
  return calculatedStars.map((item) => item).join('');
}

function loadReviews(review){
  return `
    <div class="review">

    <p class="review__name"><strong>${review.nome}</strong></p>
    <div class="review__stars">${loadStars(review.estrelas)}</div>
    <p class="review__body">${review.comentario}</p>
  </div>
    `;
}

function moveSlider(e){
  if(e.currentTarget.id.includes('right')){
    if(slideIndex < reviews.length - 1) {
      slideIndex++;
      document.querySelector('.reviews').style.transform = `translateX(${-166.7 * slideIndex}%)`;
      document.querySelector('.review-header').style.display = 'grid';
      document.querySelector('.reviews').style.display = 'flex';
    } else {
      document.querySelector('.review-header').style.display = 'none';
      document.querySelector('.reviews').style.display = 'none';

      document.querySelector('#reviewPrompt').style.display = 'block';
    }
  } else {
    if(slideIndex > 0) {
      slideIndex--;
      document.querySelector('.reviews').style.transform = `translateX(${-166.7 * slideIndex}%)`;
      document.querySelector('.review-header').style.display = 'grid';
      document.querySelector('.reviews').style.display = 'flex';
      document.querySelector('#reviewPrompt').style.display = 'none';

    }
  }
}

async function fetchReviews() {
  addEventsToReviews(); 
  document.querySelector('.reviews').innerHTML = reviews.map(loadReviews).join('');

}
fetchReviews();

// 3. Add event listeners to move the slider left and right
document.querySelector('#arrow--right').addEventListener('click', moveSlider);
document.querySelector('#arrow--left').addEventListener('click', moveSlider);

document.addEventListener('DOMContentLoaded', () => {
  const reviews = document.querySelectorAll('.review');
  const arrowLeft = document.getElementById('arrow--left');
  const arrowRight = document.getElementById('arrow--right');
  let currentIndex = 0;

  function showReview(index) {
    reviews.forEach((review, i) => {
      if (i === index) {
        review.classList.add('active');
      } else {
        review.classList.remove('active');
      }
    });
  }
})
